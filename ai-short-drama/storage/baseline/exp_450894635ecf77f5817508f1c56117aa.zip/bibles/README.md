# 制作圣经

本文件夹绑定 manifest.json 中的项目、单集和版本快照。
